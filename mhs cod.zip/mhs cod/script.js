store = null;
//fetching data from api
function getData() {
  fetch("https://random-data-api.com/api/users/random_user?size=10")
    .then((response) => {
      return response.json();
    })
    .then(function (data) {
      createElements(data);
    })
    .catch(function (err) {
      console.log(err);
    });
}
getData();
function createElements(data) {
  store = data;
  var mainContainer = document.getElementById("cardData");
  const cards = document.querySelector(".cards");
  const fragment = document.createDocumentFragment();

  for (let i = 0; i < data.length; i++) {
    const licontainer = document.createElement("li");
    licontainer.classList.add("cards_item");

    const container = document.createElement("div");
    container.classList.add("card");

    const cardImage = document.createElement("div");
    cardImage.classList.add("card_image");

    const image = document.createElement("img");
    image.setAttribute("src", data[i].avatar);

    const cardContent = document.createElement("div");
    cardContent.classList.add("card_content");

    const h2 = document.createElement("h2");
    h2.classList.add("card_title");
    h2.textContent = data[i]["first_name"] + " " + data[i]["last_name"];

    const p = document.createElement("p");
    p.classList.add("card_text");
    p.textContent = data[i]["employment"]["title"];

    const button = document.createElement("button");
    button.id = "cardBtn";
    button.textContent = "Contact Info";

    button.addEventListener("click", (e) => openModal(e, i));

    cardContent.append(h2, p, button);

    cardImage.append(image);
    container.append(cardImage, cardContent);
    licontainer.append(container);

    fragment.append(licontainer);
  }

  cards.append(fragment);
}

var modal = document.getElementById("cardModal");

function openModal(e, index) {
  const data = store[index];

  modal.querySelector(
    "h2"
  ).textContent = `Contact Info for ${data["first_name"]} ${data["last_name"]}`;
  modal.getElementsByTagName(
    "p"
  )[0].textContent = `Phone Number ${data["phone_number"]}`;
  modal.getElementsByTagName("p")[1].textContent = `Email  ${data["email"]}`;
  modal.getElementsByTagName(
    "p"
  )[2].textContent = `Address  ${data["address"]["city"]}`;

  console.log(e);
  modal.style.display = "block";
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
  modal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};
